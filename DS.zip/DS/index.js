
let arr = ['ind', 'pak', 'aus', 'ind']

let obj = {}

for(let i=0; i< arr.length; i++) {
    if(obj.hasOwnProperty(arr[i])) {
        obj[arr[i]] =  obj[arr[i]] + 1
    } else {
        obj[arr[i]] = 1
    }
}

console.log(obj)