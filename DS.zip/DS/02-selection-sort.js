function selection(arr) {
    const n = arr.length;
    let min_index;
    let temp = 0;
    for (let i=0; i< n; i++) {
        min_index = i;
        // find minimum element in array
        for (let j=i+1; j<n; j++) {
            if (arr[j]<arr[min_index]) {
                min_index = j
            }
        }
        temp = arr[min_index]
        arr[min_index] = arr[i]
        arr[i] = temp
    }
    return arr;
}

console.log(selection([64, 25, 12, 22, 9]))