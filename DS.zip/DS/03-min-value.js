function min(arr) {
    // sort array
    // give first item in array
}