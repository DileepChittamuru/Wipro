function bubble(arr) {
    let n = arr.length;
    for (let i=0; i<n; i++) {
        for (let j=0; j<n-1; j ++) {
            if(arr[j] > arr[j+1]) {
                swap(arr, arr[i], arr[j+1])
            }
        }
    }
    return arr;
}

function swap(arr, a ,b) {
    let temp = arr[a]
    arr[a] = arr[a+1]
    arr[b] = temp
}

console.log(bubble([21,32,16, 7,19]))

